<?php
//配置文件
return [
	'object_name' => 'basic',
	'template'  =>  [
	    'layout_on'     =>  true,
	    'layout_name'   =>  'layout',
	]
];